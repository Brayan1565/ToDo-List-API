import "./App.css";
import { useState } from "react";
import Encabezado from "./components/Encabezado/Encabezado";
import Buscador from "./components/Buscador/Buscador";
import Lista from "./components/Lista/Lista";
import Formulario from "./components/Formulario/Formulario";

// Datos iniciales de ejemplo; cada tarea tiene un id único y un estado "completada"
const EQUIPO = [
  { id: 1, nombre: "Ana", tarea: "Frontend", emoji: "💸", completada: false },
  { id: 2, nombre: "Luis", tarea: "Backend", emoji: "🎶", completada: true },
  { id: 3, nombre: "Sara", tarea: "Diseño", emoji: "💁🏽", completada: false },
];

function App() {
  const [equipo, setEquipo] = useState(EQUIPO); // lista completa (nunca se borra al buscar)
  const [buscar, setBuscar] = useState(""); // texto del buscador

  // Agrega una tarea nueva al final de la lista
  const agregar = (nombre, tarea) => {
    // Copiamos el arreglo para no modificar el estado original directamente
    const newEquipo = [...equipo];
    // Date.now() da un id numérico único; completada: false = empieza pendiente
    newEquipo.push({ nombre, tarea, id: Date.now(), completada: false });
    setEquipo(newEquipo);
  };

  // Lista derivada: filtra por tarea O por nombre, sin tocar el estado original
  const tareasFiltradas = equipo.filter(
    (x) =>
      x.tarea.toLowerCase().includes(buscar.toLowerCase()) ||
      x.nombre.toLowerCase().includes(buscar.toLowerCase()),
  );

  // Marca o desmarca una tarea como completada
  const alternar = (id) => {
    setEquipo(
      equipo.map((t) => (t.id === id ? { ...t, completada: !t.completada } : t)),
    );
  };

  // Elimina una tarea por su id
  const eliminar = (id) => {
    setEquipo(equipo.filter((t) => t.id !== id));
  };

  // Los totales se calculan sobre TODAS las tareas, no sobre las filtradas
  const pendientes = equipo.filter((t) => !t.completada).length;

  return (
    <>
      <Encabezado total={equipo.length} pendientes={pendientes} />
      <Buscador onBuscar={setBuscar} />
      <Formulario onAgregar={agregar} />
      <Lista
        lista={tareasFiltradas}
        onAlternar={alternar}
        onEliminar={eliminar}
      />
    </>
  );
}

export default App;
